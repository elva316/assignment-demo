from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def index():
    return "No Ninjas here!"


@app.route('/ninja/<color>/')
def colors (color):
    img = None
    if color == 'blue':
        img = 'leonardo.jpg'
    if color =="orange":
        img = 'michelangelo.jpg'
    if color == 'red':
        img = 'raphael.jpg'
    if color == 'purple':
        img = 'donatello.jpg'
    # if color == 'black':
    #     img = 'notapril.jpg'
    return render_template('index.html', dispImg = img or 'notapril.jpg')
    # return render_template('index.html', dispImg = img)

@app.route('/ninja')
def nijia():
    return render_template('index.html', dispImg = 'tmnt.png')

app.run(debug = True)
